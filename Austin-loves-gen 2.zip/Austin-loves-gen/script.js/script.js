// Scene setup
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  1000
);
const renderer = new THREE.WebGLRenderer({ canvas: document.getElementById("bg"), antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(window.devicePixelRatio);

// Orbit controls (manual rotate/zoom)
let isDragging = false;
let previousMousePosition = { x: 0, y: 0 };
let scale = 1;

// Load textures (12 photos)
const loader = new THREE.TextureLoader();
const photoMeshes = [];
for (let i = 1; i <= 12; i++) {
  const texture = loader.load(`assets/img${i}.jpg`);
  const geometry = new THREE.PlaneGeometry(3, 2);
  const material = new THREE.MeshBasicMaterial({ map: texture, side: THREE.DoubleSide });
  const mesh = new THREE.Mesh(geometry, material);

  // Position randomly in sphere
  const radius = 15;
  const phi = Math.acos(2 * Math.random() - 1);
  const theta = 2 * Math.PI * Math.random();
  mesh.position.set(
    radius * Math.sin(phi) * Math.cos(theta),
    radius * Math.sin(phi) * Math.sin(theta),
    radius * Math.cos(phi)
  );

  scene.add(mesh);
  photoMeshes.push(mesh);
}

// Hearts particles
const heartGeometry = new THREE.CircleGeometry(0.1, 6);
const heartMaterial = new THREE.MeshBasicMaterial({ color: 0xff69b4 });
const hearts = [];
for (let i = 0; i < 200; i++) {
  const heart = new THREE.Mesh(heartGeometry, heartMaterial);
  heart.position.set(
    (Math.random() - 0.5) * 30,
    Math.random() * 30 - 15,
    (Math.random() - 0.5) * 30
  );
  scene.add(heart);
  hearts.push(heart);
}

// Falling text
const textCanvas = document.createElement('canvas');
const ctx = textCanvas.getContext('2d');
textCanvas.width = 256;
textCanvas.height = 64;
ctx.font = '24px Arial';
ctx.fillStyle = 'pink';
ctx.textAlign = 'center';
ctx.fillText('I LOVE YOU SO MUCH GAV', 128, 32);
const textTexture = new THREE.CanvasTexture(textCanvas);
const textMaterial = new THREE.SpriteMaterial({ map: textTexture });
const texts = [];
for (let i = 0; i < 50; i++) {
  const sprite = new THREE.Sprite(textMaterial);
  sprite.position.set(
    (Math.random() - 0.5) * 30,
    Math.random() * 30 - 15,
    (Math.random() - 0.5) * 30
  );
  scene.add(sprite);
  texts.push(sprite);
}

// Camera position
camera.position.z = 25;

// Animation loop
function animate() {
  requestAnimationFrame(animate);

  // Move hearts down
  hearts.forEach(h => {
    h.position.y -= 0.05;
    if (h.position.y < -15) h.position.y = 15;
  });

  // Move texts down
  texts.forEach(t => {
    t.position.y -= 0.03;
    if (t.position.y < -15) t.position.y = 15;
  });

  renderer.render(scene, camera);
}
animate();

// Mouse and touch controls
document.addEventListener("mousedown", (e) => {
  isDragging = true;
  previousMousePosition = { x: e.clientX, y: e.clientY };
});
document.addEventListener("mouseup", () => isDragging = false);
document.addEventListener("mousemove", (e) => {
  if (!isDragging) return;
  const deltaX = e.clientX - previousMousePosition.x;
  const deltaY = e.clientY - previousMousePosition.y;
  scene.rotation.y += deltaX * 0.005;
  scene.rotation.x += deltaY * 0.005;
  previousMousePosition = { x: e.clientX, y: e.clientY };
});

// Touch support
let lastTouchDist = null;
document.addEventListener("touchstart", (e) => {
  if (e.touches.length === 2) {
    lastTouchDist = getTouchDistance(e.touches);
  }
});
document.addEventListener("touchmove", (e) => {
  if (e.touches.length === 1) {
    // Rotate
    const deltaX = e.touches[0].clientX - previousMousePosition.x;
    const deltaY = e.touches[0].clientY - previousMousePosition.y;
    scene.rotation.y += deltaX * 0.005;
    scene.rotation.x += deltaY * 0.005;
    previousMousePosition = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  } else if (e.touches.length === 2) {
    // Zoom
    const dist = getTouchDistance(e.touches);
    if (lastTouchDist) {
      const scaleChange = (dist - lastTouchDist) * 0.01;
      camera.position.z -= scaleChange;
      if (camera.position.z < 5) camera.position.z = 5;
      if (camera.position.z > 50) camera.position.z = 50;
    }
    lastTouchDist = dist;
  }
});
function getTouchDistance(touches) {
  const dx = touches[0].clientX - touches[1].clientX;
  const dy = touches[0].clientY - touches[1].clientY;
  return Math.sqrt(dx * dx + dy * dy);
}

// Music autoplay on tap
document.body.addEventListener("click", () => {
  const music = document.getElementById("bg-music");
  music.play();
});