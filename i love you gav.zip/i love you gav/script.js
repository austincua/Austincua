
// Scene setup
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({canvas: document.getElementById('bg')});
renderer.setSize(window.innerWidth, window.innerHeight);

// Move camera farther back for wide view
camera.position.z = 25;

// Group to rotate
const group = new THREE.Group();
scene.add(group);

// Texture loader
const loader = new THREE.TextureLoader();

// Colors
const colors = [
  new THREE.MeshBasicMaterial({ color: 0xff69b4 }), // pink
  new THREE.MeshBasicMaterial({ color: 0xbf40bf }), // purple
  new THREE.MeshBasicMaterial({ color: 0xffffff })  // white
];

// Falling objects array
let fallingObjects = [];

// Function to create "I LOVE YOU" text plane
function createTextMesh() {
    const textCanvas = document.createElement('canvas');
    const ctx = textCanvas.getContext('2d');
    textCanvas.width = 256;
    textCanvas.height = 64;
    ctx.fillStyle = 'white';
    ctx.font = '28px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('I LOVE YOU', 128, 32);
    const textTexture = new THREE.CanvasTexture(textCanvas);
    return new THREE.Mesh(new THREE.PlaneGeometry(5, 1), new THREE.MeshBasicMaterial({ map: textTexture, transparent: true }));
}

// Function to spawn photos, hearts, and text
function spawnFallingObjects() {
    for (let i = 0; i < 10; i++) {
        // Photos
        const texture = loader.load(`assets/img${(i % 12) + 1}.jpg`);
        const photo = new THREE.Mesh(new THREE.PlaneGeometry(3, 3), new THREE.MeshBasicMaterial({ map: texture, side: THREE.DoubleSide }));
        photo.position.set((Math.random() - 0.5) * 40, 20 + Math.random() * 10, (Math.random() - 0.5) * 20);
        photo.userData.speed = 0.05 + Math.random() * 0.1;
        fallingObjects.push(photo);
        group.add(photo);

        // Text
        const textMesh = createTextMesh();
        textMesh.position.set((Math.random() - 0.5) * 40, 20 + Math.random() * 10, (Math.random() - 0.5) * 20);
        textMesh.userData.speed = 0.05 + Math.random() * 0.1;
        fallingObjects.push(textMesh);
        group.add(textMesh);

        // Hearts
        const heart = new THREE.Mesh(new THREE.CircleGeometry(0.2, 32), colors[Math.floor(Math.random() * colors.length)]);
        heart.position.set((Math.random() - 0.5) * 40, 20 + Math.random() * 10, (Math.random() - 0.5) * 20);
        heart.userData.speed = 0.05 + Math.random() * 0.1;
        fallingObjects.push(heart);
        group.add(heart);
    }
}

// Spawn objects repeatedly
setInterval(spawnFallingObjects, 300);

// Animate
function animate() {
    requestAnimationFrame(animate);
    fallingObjects.forEach(obj => {
        obj.position.y -= obj.userData.speed;
        if (obj.position.y < -20) {
            group.remove(obj);
        }
    });
    renderer.render(scene, camera);
}
animate();

// Manual controls (touch & mouse)
let isDragging = false;
let prevX, prevY;

function startDrag(x, y) {
    isDragging = true;
    prevX = x;
    prevY = y;
}

function moveDrag(x, y) {
    if (!isDragging) return;
    let deltaX = x - prevX;
    let deltaY = y - prevY;
    group.rotation.y += deltaX * 0.01;
    group.rotation.x += deltaY * 0.01;
    prevX = x;
    prevY = y;
}

function endDrag() {
    isDragging = false;
}

// Touch events
document.addEventListener('touchstart', (e) => {
    if (e.touches.length === 1) {
        startDrag(e.touches[0].clientX, e.touches[0].clientY);
    } else if (e.touches.length === 2) {
        initialDistance = Math.hypot(
            e.touches[0].clientX - e.touches[1].clientX,
            e.touches[0].clientY - e.touches[1].clientY
        );
    }
});

document.addEventListener('touchmove', (e) => {
    if (e.touches.length === 1) {
        moveDrag(e.touches[0].clientX, e.touches[0].clientY);
    } else if (e.touches.length === 2) {
        const newDistance = Math.hypot(
            e.touches[0].clientX - e.touches[1].clientX,
            e.touches[0].clientY - e.touches[1].clientY
        );
        const zoomFactor = (initialDistance - newDistance) * 0.01;
        camera.position.z += zoomFactor;
        initialDistance = newDistance;
    }
});

document.addEventListener('touchend', endDrag);

// Mouse events
document.addEventListener('mousedown', (e) => startDrag(e.clientX, e.clientY));
document.addEventListener('mousemove', (e) => moveDrag(e.clientX, e.clientY));
document.addEventListener('mouseup', endDrag);
document.addEventListener('wheel', (e) => {
    camera.position.z += e.deltaY * 0.01;
});

// Music on tap/click
document.body.addEventListener('click', () => {
    const music = document.getElementById('bg-music');
    if (music.paused) {
        music.play();
    }
}, { once: true });

window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});
